from django.apps import AppConfig


class GamificationConfig(AppConfig):
    name = 'gamification'
