from django.apps import AppConfig


class TimetrackingConfig(AppConfig):
    name = 'timetracking'
