from django.apps import AppConfig

class UsersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'users'
    verbose_name = "Сотрудники"

    def ready(self):
        import users.signals  # Импортируем сигналы